package com.gamingroom;

/**
 * A class to test a singleton's behavior
 * 
 * @author Stephen.bailey@snhu.edu
 */
public class SingletonTester {

    public void testSingleton() {

        System.out.println("\nAbout to test the singleton...");

        // Obtain local reference to the singleton instance
        GameService service = GameService.getInstance(); // Singleton pattern: obtains the single instance of GameService

        // A simple for loop to print the games
        for (int i = 0; i < service.getGames().size(); i++) {
            System.out.println(service.getGames().get(i).getName()); // Iterator pattern: iterates through the list of games
        }

    }

    public static void main(String[] args) {
        SingletonTester tester = new SingletonTester();
        
        // Adding some games for testing
        GameService service = GameService.getInstance(); // Singleton pattern: obtains the single instance of GameService
        service.addGame("Game1");
        service.addGame("Game2");
        
        tester.testSingleton(); // Tests the singleton behavior by printing game names
    }
}
